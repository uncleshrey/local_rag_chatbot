import re
from random import choice

SMALL_TALK_PATTERNS = [
    r"^\s*hi\s*$",
    r"^\s*hello\s*$",
    r"^\s*hey\s*$",
    r"^\s*yo\s*$",
    r"^\s*good\s*(morning|afternoon|evening)\s*$",
    r"^\s*how\s*are\s*you\??\s*$",
]

def is_small_talk(text: str) -> bool:
    t = text.strip().lower()
    return any(re.match(p, t) for p in SMALL_TALK_PATTERNS)

def small_talk_reply(tone: str = "friendly") -> str:
    friendly = [
        "Hey there! 😊 What would you like to explore from your PDFs?",
        "Hi! 👋 Ready to dive into your documents?",
        "Hello! 🙂 Ask me anything from the PDFs and I’ll fetch it.",
    ]
    return choice(friendly)
