import os
import shutil
from typing import List, Optional

from langchain.embeddings import OllamaEmbeddings
from langchain.vectorstores import Chroma
from langchain.schema import Document

def build_or_load_vectorstore(
    chunks: Optional[List[Document]],
    persist_directory: str = "chroma_db",
    embedding_model: str = "nomic-embed-text",
    force_rebuild: bool = False,
) -> Chroma:
    embedding = OllamaEmbeddings(model=embedding_model)

    db_exists = os.path.isdir(persist_directory) and any(
        name for name in os.listdir(persist_directory)
    )

    if force_rebuild and os.path.isdir(persist_directory):
        print("🧹 Force rebuild: deleting existing DB...")
        shutil.rmtree(persist_directory, ignore_errors=True)
        db_exists = False

    if db_exists:
        print("📦 Loading existing Chroma DB...")
        return Chroma(persist_directory=persist_directory, embedding_function=embedding)

    if not chunks:
        print("⚠️  No chunks provided. Creating empty DB connection (retrieval may return nothing).");
        return Chroma(persist_directory=persist_directory, embedding_function=embedding)

    print("🧩 Creating new Chroma DB from chunks...")
    vs = Chroma.from_documents(chunks, embedding=embedding, persist_directory=persist_directory)
    vs.persist()
    print("✅ Vector DB created & persisted")
    return vs
