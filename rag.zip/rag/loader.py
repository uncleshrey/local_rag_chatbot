import os
from typing import List
from langchain.document_loaders import PyPDFLoader
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.schema import Document

def load_all_pdfs(folder_path: str) -> List[Document]:
    docs = []
    if not os.path.isdir(folder_path):
        print(f"⚠️  Docs folder not found: {folder_path}")
        return docs

    for fname in os.listdir(folder_path):
        if fname.lower().endswith(".pdf"):
            path = os.path.join(folder_path, fname)
            try:
                loader = PyPDFLoader(path)
                docs.extend(loader.load())
            except Exception as e:
                print(f"❌ Failed to load {fname}: {e}")
    return docs

def split_documents(documents: List[Document], chunk_size=1000, chunk_overlap=200) -> List[Document]:
    splitter = RecursiveCharacterTextSplitter(
        chunk_size=chunk_size,
        chunk_overlap=chunk_overlap,
        separators=["\n\n", "\n", " ", ""],
    )
    return splitter.split_documents(documents)

def load_and_split_pdfs(folder_path: str) -> List[Document]:
    documents = load_all_pdfs(folder_path)
    if not documents:
        print("⚠️  No PDFs found or failed to load. Continuing anyway (DB may already exist).");
        return []
    chunks = split_documents(documents)
    print(f"✅ Loaded {len(documents)} documents → {len(chunks)} chunks")
    return chunks
