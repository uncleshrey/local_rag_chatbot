from langchain.retrievers.multi_query import MultiQueryRetriever
from langchain.retrievers.document_compressors import LLMChainExtractor
from langchain.retrievers import ContextualCompressionRetriever
from langchain.vectorstores import Chroma
from langchain.llms.base import LLM

def build_multiquery_compressed_retriever(
    vectorstore: Chroma,
    llm: LLM,
    k_base: int = 8,
    k_final: int = 4,
):
    base_retriever = vectorstore.as_retriever(search_kwargs={"k": k_base})

    multiquery_retriever = MultiQueryRetriever.from_llm(
        retriever=base_retriever,
        llm=llm,
        include_original=True,
    )

    compressor = LLMChainExtractor.from_llm(llm)
    compressed_retriever = ContextualCompressionRetriever(
        base_compressor=compressor,
        base_retriever=multiquery_retriever,
        k=k_final
    )

    return compressed_retriever
